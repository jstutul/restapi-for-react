from django.contrib import admin
from status.models import *
# Register your models here.

admin.site.register(Student)
