from django.apps import AppConfig


class AllinoneConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'allinone'
